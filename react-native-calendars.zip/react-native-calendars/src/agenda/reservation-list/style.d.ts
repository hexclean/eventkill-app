import { Theme } from '../../types';
export default function styleConstructor(theme?: Theme): any;
