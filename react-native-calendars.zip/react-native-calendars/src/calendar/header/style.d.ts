import { Theme } from '../../types';
export default function (theme?: Theme): any;
