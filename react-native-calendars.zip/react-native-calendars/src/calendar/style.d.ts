import { Theme } from '../types';
export default function getStyle(theme?: Theme): any;
