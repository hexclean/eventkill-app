import React from 'react';
declare const CalendarContext: React.Context<{}>;
export default CalendarContext;
