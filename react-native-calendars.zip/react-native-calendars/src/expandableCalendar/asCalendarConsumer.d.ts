import React from 'react';
declare function asCalendarConsumer(WrappedComponent: React.ComponentType<any>): React.ComponentClass;
export default asCalendarConsumer;
