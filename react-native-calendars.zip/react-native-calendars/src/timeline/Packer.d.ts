import { Event } from './Timeline';
declare function populateEvents(events: Event[], screenWidth: number, dayStart: number): Event[];
export default populateEvents;
